/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isp392.blog;

/**
 *
 * @author ThinhHoang
 */
public class BlogDTO {
    private int blogID;
    private String title;
    private String image;
    private String description;
    //private createDate;
    private boolean status;
}
